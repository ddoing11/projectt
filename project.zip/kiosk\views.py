from django.shortcuts import render
from django.http import JsonResponse
from .models import MenuItem
import json
from django.views.decorators.csrf import csrf_exempt

# 시작 페이지
def start(request):
    return render(request, 'start.html')

# 음성 주문 시작 페이지
def order_start_voice(request):
    return render(request, 'kiosk/order_start_voice.html')


# 주문 페이지
def order(request):
    return render(request, 'order.html')

# 음성 텍스트 변환 및 메뉴 처리
@csrf_exempt
def speech_to_text(request):
    if request.method == "POST":
        body = json.loads(request.body)
        user_text = body.get("text", "").strip()

        # DB에서 메뉴 이름 목록 불러오기
        menu_items = MenuItem.objects.all()
        menu_names = [item.name for item in menu_items]

        # 메뉴 이름이 텍스트에 포함되어 있는지 확인
        matched_menu = next((name for name in menu_names if name in user_text), None)

        if matched_menu:
            menu = MenuItem.objects.get(name=matched_menu)
            response = f"{menu.name}는 {menu.price}원입니다. 구매하시겠습니까?"
        else:
            response = "죄송합니다. 메뉴에서 찾을 수 없어요. 다시 말씀해 주세요."

        return JsonResponse({"response": response})
    return JsonResponse({"error": "Invalid request"}, status=400)

# 사용자 명령 처리 (키워드 기반)
@csrf_exempt
def process_command(request):
    if request.method == "POST":
        body = json.loads(request.body)  # POST로 받은 JSON 데이터를 처리
        user_text = body.get("text", "").lower()  # 사용자 텍스트 받기
        keywords = ["커피", "음료", "디저트", "시원한", "따뜻한"]  # 예시 키워드 리스트

        # 사용자가 말한 텍스트에서 키워드 매칭
        matched_keywords = [keyword for keyword in keywords if keyword in user_text]

        if matched_keywords:
            response_text = f"사용자가 '{user_text}'라고 말했습니다. 추천 메뉴를 찾아봅니다..."

            # 카테고리별 메뉴 필터링
            if "커피" in matched_keywords:
                menu_items = MenuItem.objects.filter(category='coffee')
            elif "음료" in matched_keywords:
                menu_items = MenuItem.objects.filter(category='drink')
            elif "디저트" in matched_keywords:
                menu_items = MenuItem.objects.filter(category='dessert')
            else:
                menu_items = MenuItem.objects.all()

            menu_list = [item.name for item in menu_items]
            response_text = f"추천 메뉴: {', '.join(menu_list)}"

            return JsonResponse({"response": response_text})
        else:
            return JsonResponse({"response": "저는 아직 그 메뉴를 이해할 수 없습니다."})

    return JsonResponse({"error": "Invalid request"}, status=400)

# 사용자 응답 처리
@csrf_exempt
def process_response(request):
    if request.method == "POST":
        body = json.loads(request.body)
        user_response = body.get("response", "").lower()

        # 사용자가 긍정적인 응답을 한 경우 (표현 다양화)
        positive_responses = ["네", "응", "좋아", "그래", "예", "오케이", "ㅇㅇ", "근데 왜요", "어", "주문 시작", "주문해", "주문할래"]


        if any(positive_response in user_response for positive_response in positive_responses):
            return JsonResponse({"response": "음성 주문을 시작합니다."})
        else:
            return JsonResponse({"response": "다시 말씀해 주세요."})

    return JsonResponse({"error": "Invalid request"}, status=400)

# 웹소켓 테스트 페이지
def websocket_test(request):
    return render(request, 'kiosk/websocket_test.html')