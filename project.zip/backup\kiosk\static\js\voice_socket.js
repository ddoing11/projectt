﻿"use strict";

// ✅ WebSocket 연결
const socket = new WebSocket('ws://127.0.0.1:8002');

const audioContext = new (window.AudioContext || window.webkitAudioContext)();
let mediaStream = null;
let processorNode = null;

socket.onopen = () => {
  console.log('✅ WebSocket 연결됨');
  checkMicrophonePermission();
};

function checkMicrophonePermission() {
  navigator.permissions.query({ name: 'microphone' }).then(result => {
    if (result.state === 'granted' || result.state === 'prompt') {
      requestMicrophoneAccess();
    } else {
      console.warn('🚫 마이크 권한 없음');
    }
  });
}

function requestMicrophoneAccess() {
  navigator.mediaDevices.getUserMedia({ audio: true })
    .then(stream => {
      mediaStream = stream;
      startRecording();
    })
    .catch(err => console.error('❌ 마이크 접근 실패:', err));
}

async function startRecording() {
  try {
    await audioContext.audioWorklet.addModule('/static/js/pcm-processor.js');
    console.log("✅ Worklet 모듈 로드 성공");

    const source = audioContext.createMediaStreamSource(mediaStream);
    processorNode = new AudioWorkletNode(audioContext, 'pcm-processor');

    processorNode.port.onmessage = event => {
      if (event.data && event.data.pcm) {
        socket.send(event.data.pcm);
      }
    };

    source.connect(processorNode).connect(audioContext.destination);

  } catch (err) {
    console.error("🚫 Worklet 모듈 로드 실패:", err);

    // 추가 디버깅: 해당 JS 파일이 실제로 무엇을 응답하는지 확인
    try {
      const res = await fetch('/static/js/pcm-processor.js');
      const text = await res.text();
      console.log("📄 파일 내용 미리보기 (앞부분):", text.slice(0, 200));
    } catch (fetchErr) {
      console.error("❌ pcm-processor.js fetch 실패:", fetchErr);
    }
  }
}

socket.onmessage = (event) => {
  const text = event.data.trim();
  console.log('🗣 받은 텍스트:', text);
  document.getElementById("output").innerText = text;

  if (!text || text === "조용히 해 주십시오. 배경음을 녹음중입니다.") return;

  fetch("http://127.0.0.1:8000/process-response/", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ response: text })
  })
  .then(res => res.json())
  .then(data => {
    const responseText = data.response;
    console.log("✅ 서버 판단 결과:", responseText);

    if (responseText.includes("음성 주문을 시작합니다")) {
      speakText(responseText, () => {
        window.location.href = "/order/";
      });
    } else if (responseText.includes("다시 말씀해 주세요")) {
      fetch("http://127.0.0.1:8000/process-command/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text })
      })
      .then(res => res.json())
      .then(cmdData => {
        console.log("✅ 추천 응답:", cmdData.response);
        speakText(cmdData.response);
      });
    } else {
      speakText(responseText);
    }
  })
  .catch(err => {
    console.error("❌ 서버 처리 중 오류:", err);
  });
};

function speakText(text, onEnd = null) {
  const utterance = new SpeechSynthesisUtterance(text);
  if (onEnd) utterance.onend = onEnd;
  speechSynthesis.speak(utterance);
}

socket.onclose = () => {
  console.warn("🔌 WebSocket 연결 종료");
  if (mediaStream) mediaStream.getTracks().forEach(track => track.stop());
};

socket.onerror = (error) => {
  console.error("❌ WebSocket 오류:", error);
};
