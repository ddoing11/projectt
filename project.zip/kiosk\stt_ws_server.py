import sys, os, asyncio, websockets
import azure.cognitiveservices.speech as speechsdk
from websockets.legacy.server import serve

# 전역 이벤트 루프
loop = asyncio.get_event_loop()

# Azure Speech 서비스 설정
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'backend', 'aptitude'))
from local_settings import AZURE_SPEECH_KEY, AZURE_SPEECH_REGION

AZURE_KEY = AZURE_SPEECH_KEY
AZURE_REGION = AZURE_SPEECH_REGION

# ✅ Custom Speech 모델 endpoint ID
CUSTOM_SPEECH_ENDPOINT_ID = "087eba3b-1d7c-4f9d-9dbf-ed6f2e7ac638"

async def recognize_from_microphone(websocket):
    speech_config = speechsdk.SpeechConfig(subscription=AZURE_KEY, region=AZURE_REGION)
    speech_config.speech_recognition_language = "ko-KR"
    speech_config.endpoint_id = CUSTOM_SPEECH_ENDPOINT_ID

    stream = speechsdk.audio.PushAudioInputStream()
    audio_config = speechsdk.audio.AudioConfig(stream=stream)
    recognizer = speechsdk.SpeechRecognizer(speech_config, audio_config)

    def recognized(evt):
        if evt.result.text:
            print("📝 인식 결과:", evt.result.text)
            asyncio.run_coroutine_threadsafe(
                websocket.send(evt.result.text),
                loop
            )

    recognizer.recognized.connect(recognized)
    recognizer.start_continuous_recognition()

    silent_seconds = 0

    try:
        print("⏳ 초기 5초 대기 중...")
        await asyncio.sleep(5)  # 초기 5초 대기

        while True:
            try:
                data = await asyncio.wait_for(websocket.recv(), timeout=1.0)  # 매 1초마다 감시
                if isinstance(data, bytes):
                    print(f"🎧 PCM 데이터 수신: {len(data)} bytes")
                    stream.write(data)
                    silent_seconds = 0  # 데이터 오면 무음 시간 리셋
            except asyncio.TimeoutError:
                silent_seconds += 1
                if silent_seconds % 10 == 0:
                    print(f"⏳ 무음 지속: {silent_seconds}초 경과")

                if silent_seconds >= 300:  # 5분(300초) 동안 데이터 없음
                    print("🤫 5분 무음 감지 → 스트림 종료")
                    break

    except websockets.exceptions.ConnectionClosed:
        print("⚡ WebSocket 연결 끊김")
    finally:
        recognizer.stop_continuous_recognition()
        stream.close()
        print("🔚 인식기 및 스트림 종료 완료")

async def handler(websocket, path):
    await recognize_from_microphone(websocket)

async def main():
    async with serve(handler, "0.0.0.0", 8002):
        print("🚀 Azure Custom Speech WebSocket 서버가 실행 중입니다...")
        await asyncio.Future()

if __name__ == "__main__":
    loop.run_until_complete(main())
