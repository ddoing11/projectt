from django.urls import path
from . import views

urlpatterns = [
    path('', views.start, name='start'),
    path('order/', views.order, name='order'),
    path('speech-to-text/', views.speech_to_text, name='speech_to_text'),
    path('process-command/', views.process_command, name='process_command'),
    path('process-response/', views.process_response, name='process_response'),  # ✅ 여기에 정의해야 함
    path('websocket-test/', views.websocket_test, name='websocket_test'),
]
