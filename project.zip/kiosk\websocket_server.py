import asyncio
import websockets
import cv2
import time
import azure.cognitiveservices.speech as speechsdk
import json
import sys
import os

# local_settings.py를 절대경로로 불러오기
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'backend', 'aptitude'))
from local_settings import AZURE_SPEECH_KEY, AZURE_SPEECH_REGION

# 상태 변수
last_detection_time = None
DETECTION_TIME_THRESHOLD = 3
NO_DETECTION_THRESHOLD = 5
voice_output_done = False
order_in_progress = False

# WebSocket 클라이언트 저장
connected_clients = set()

def speak_text(text):
    print(f"[\U0001F50A 음성 출력 시작] {text}")
    speech_config = speechsdk.SpeechConfig(subscription=AZURE_SPEECH_KEY, region=AZURE_SPEECH_REGION)
    speech_config.speech_synthesis_voice_name = "ko-KR-SunHiNeural"
    synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config)
    result = synthesizer.speak_text_async(text).get()
    if result.reason == speechsdk.ResultReason.Canceled:
        cancellation_details = result.cancellation_details
        print(f"[❌ 음성 실패] Reason: {result.reason}\n   - 이유: {cancellation_details.reason}\n   - 세부사항: {cancellation_details.error_details}")
    else:
        print("[✅ 음성 출력 완료]")

def process_negative_response(response):
    return any(word in response for word in ["아니", "싫어"])

def process_positive_response(response):
    return any(word in response for word in ["네", "응", "좋아", "그래", "예", "오케이", "ㅇㅇ", "근데 왜요", "어", "주문 시작", "주문해", "주문할래"])

async def echo(websocket, path):
    print(f"\n클라이언트 연결됨: {path}")
    connected_clients.add(websocket)
    try:
        async for message in websocket:
            print(f"메시지 받음: {message}")
            if process_negative_response(message):
                await websocket.send("음성 인식 종료")
            elif process_positive_response(message):
                await websocket.send("음성 주문을 시작합니다.")
            else:
                await websocket.send(f"서버 응답: {message}")
    except websockets.ConnectionClosed:
        print("🔌 클라이언트 연결 종료")
    finally:
        connected_clients.remove(websocket)

async def start_server():
    server = await websockets.serve(echo, "localhost", 8001)
    print("✅ 웹소켓 서버 실행 중")
    await server.wait_closed()

def start_face_detection():
    global last_detection_time, voice_output_done, order_in_progress
    cap = cv2.VideoCapture(0)

    if not cap.isOpened():
        print("🚫 카메라를 열 수 없습니다.")
        return

    print("🎥 얼굴 감지 시작")
    cv2.namedWindow("Detection", cv2.WINDOW_NORMAL)

    while True:
        ret, frame = cap.read()
        if not ret:
            print("❌ 프레임을 읽지 못했습니다.")
            break

        fgmask = cv2.createBackgroundSubtractorMOG2().apply(frame)
        contours, _ = cv2.findContours(fgmask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        person_detected = False

        for contour in contours:
            area = cv2.contourArea(contour)
            if area > 1000:
                print(f"👤 감지된 움직임 (면적: {area})")
                person_detected = True
                if last_detection_time is None:
                    last_detection_time = time.time()
                else:
                    time_elapsed = time.time() - last_detection_time
                    if time_elapsed >= DETECTION_TIME_THRESHOLD and not voice_output_done:
                        if not order_in_progress:
                            print(f"[🗣 조건 만족: {time_elapsed:.2f}초 경과 → 음성 출력 시도]")
                            speak_text("안녕하세요, 음성으로 주문하시겠습니까?")
                            voice_output_done = True
                            order_in_progress = True
                        last_detection_time = None

        if not person_detected:
            if last_detection_time is not None:
                time_elapsed = time.time() - last_detection_time
                if time_elapsed >= NO_DETECTION_THRESHOLD:
                    print("🚪 사람이 사라졌습니다. 주문 종료 상태로 전환")
                    order_in_progress = False
                    voice_output_done = False
                    last_detection_time = None

        cv2.imshow("Detection", frame)
        print("[🖼 프레임 표시됨]")
        if cv2.waitKey(1) & 0xFF == ord('q'):
            print("❌ 종료 키 입력됨. 프로그램 종료")
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    try:
        loop = asyncio.get_event_loop()
        loop.create_task(start_server())
        start_face_detection()
    except KeyboardInterrupt:
        print("\n❌ 프로그램 종료됨")
