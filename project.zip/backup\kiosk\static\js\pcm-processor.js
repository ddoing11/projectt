﻿export {};  // ✅ 꼭 추가!

class PCMProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    this.buffer = [];
    this.bufferSize = 4096;
  }

  process(inputs) {
    const input = inputs[0];
    if (input.length === 0) return true;

    const channelData = input[0];
    for (let i = 0; i < channelData.length; i++) {
      let s = Math.max(-1, Math.min(1, channelData[i]));
      s = s < 0 ? s * 0x8000 : s * 0x7FFF;
      this.buffer.push(s | 0);
    }

    if (this.buffer.length >= this.bufferSize) {
      const pcm16 = new Int16Array(this.buffer);
      const pcmBytes = new Uint8Array(pcm16.buffer);
      this.port.postMessage({ pcm: pcmBytes });
      this.buffer = [];
    }

    return true;
  }
}

registerProcessor('pcm-processor', PCMProcessor);
